﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AG
{
    public partial class DisplayT : Form
    {
        public DisplayT()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MySqlConnection Con = new MySqlConnection("server=localhost;Username = gym;database=project_ag;password=1234");
            MySqlDataAdapter dataAdapter = new MySqlDataAdapter("select * from add_teacher", Con);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "add_teacher");
            dataGridView1.DataSource = ds.Tables[name: "add_teacher"].DefaultView;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {


        }
    }
}
