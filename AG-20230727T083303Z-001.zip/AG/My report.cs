﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AG
{
    public partial class Leave_Report2 : Form
    {
        public Leave_Report2()
        {
            InitializeComponent();
        }
    }
}
