﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AG
{
    public partial class StaffMenu : Form
    {
        public StaffMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Addcourse addcourse = new Addcourse();
            addcourse.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Logout2 logout2 = new Logout2();
            logout2.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Addstudent addstudent = new Addstudent();
            addstudent.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FillaAttendance filla = new FillaAttendance();
            filla.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LeaveReport leaveReport = new LeaveReport();
            leaveReport.Show();
        }
    }
}
