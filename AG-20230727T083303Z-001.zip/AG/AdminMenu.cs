﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AG
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Remove_teacher remove_Teacher = new Remove_teacher();
            remove_Teacher.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Add_Teacher add_Teacher = new Add_Teacher();
            add_Teacher.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Logout1 logout1 = new Logout1();
            logout1.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            DisplayT displayT = new DisplayT();
            displayT.Show();
        }
    }
}
