﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AG
{
    public partial class Addstudent : Form
    {
        public Addstudent()
        {
            InitializeComponent();
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void Addstudent_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection Con = new MySqlConnection("server=localhost;Username = gym;database=project_ag;password=1234");
            string gender = "";
            string lst = listBox1.Text;
            string lst2=listBox2.Text;
            if (radioButton1.Checked)
            {
                gender = "M";
            }
            else if (radioButton2.Checked)
            {
                gender = "F";
            }
            MySqlCommand Command = new MySqlCommand("insert into Add_teacher values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','"+lst+"','" + textBox6.Text + "', '"+ gender+"','"+lst2+"' )", Con);
            Con.Open();
            MessageBox.Show("Added successfully");
            Command.ExecuteNonQuery();
            Con.Close();
        }
    }
}
