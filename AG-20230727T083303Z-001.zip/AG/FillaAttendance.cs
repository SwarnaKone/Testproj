﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AG
{
    public partial class FillaAttendance : Form
    {
        public FillaAttendance()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string lst = "";
            lst = listBox1.Text;
            MySqlConnection Con = new MySqlConnection("server=localhost;Username = gym;database=project_ag;password=1234");
            MySqlCommand Command = new MySqlCommand("select F.* from add_student a right outer join fill_attendance F on a.ID=F.ID where a.course='" + lst + "' )", Con);
            Con.Open();
            Command.ExecuteNonQuery();
            Con.Close();
        }
    }
}
