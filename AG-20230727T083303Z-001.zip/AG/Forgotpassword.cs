﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AG
{
    public partial class Forgotpassword : Form
    {
        public Forgotpassword()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection Con = new MySqlConnection("server=localhost;UserControl Id = gym;database=project_ag;password=1234");
            MySqlCommand Command = new MySqlCommand("update Reg_tb set password='" + textBox2.Text + "' where username='"+ textBox1.Text + "')", Con);
            if (textBox2.Text == textBox3.Text)
            {
                Con.Open();
                MessageBox.Show("Register successfully");
                Command.ExecuteNonQuery();
                Con.Close();
            }
            else
            {
                MessageBox.Show("Password and confirm password are not same,try again");
            }
        }
    }
}
