using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace AG
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            MySqlConnection Con = new MySqlConnection("server=localhost;Username = gym;database=project_ag;password=1234");
            try
            {

                MySqlDataAdapter Da = new MySqlDataAdapter("select * from Login_tb where username='" + textBox1.Text + "' and Password='" + textBox2.Text + "';", Con);
                DataTable dt = new DataTable();
                Da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Login successfully..");
                    adminMenu.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid username and password");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Con.Close();
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Forgotpassword forgotpassword = new Forgotpassword();
            forgotpassword.Show();
            this.Hide();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Reg reg = new Reg();
            reg.Show();
            this.Hide();
        }
    }
}