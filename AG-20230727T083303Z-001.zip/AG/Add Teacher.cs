﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AG
{
    public partial class Add_Teacher : Form
    {
        public Add_Teacher()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Add_Teacher_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection Con = new MySqlConnection("server=localhost;Username = gym;database=project_ag;password=1234");
            string gender = "";
            string lst = listBox1.Text;
            if (radioButton1.Checked)
            {
                gender = "M";
            }
            else if (radioButton2.Checked)
            {
                gender = "F";
            }
            MySqlCommand Command = new MySqlCommand("insert into Add_teacher (Name,Email,Contact,Qualification,Address,Gender)values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + lst + "','" + textBox5.Text + "', '" + gender + "' )", Con);
            Con.Open();
            MessageBox.Show("Added successfully");
            Command.ExecuteNonQuery();
            Con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}

