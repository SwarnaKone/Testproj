﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AG
{
    public partial class Addcourse : Form
    {
        public Addcourse()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            MySqlConnection Con = new MySqlConnection("server=localhost;Username = gym;database=project_ag;password=1234");
            MySqlCommand Command = new MySqlCommand("insert into Add_course values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')", Con);
            Con.Open();
            MessageBox.Show("Add cousre successfully");
            Command.ExecuteNonQuery();
            Con.Close();
        }
    }
}
